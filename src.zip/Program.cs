using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

public class MainForm : Form
{
    private Button btnKillProcesses;
    private Label lblStatus;

    public MainForm()
    {
        // 폼 설정
        this.Text = "Process Killer";
        this.Size = new System.Drawing.Size(400, 200);
        this.StartPosition = FormStartPosition.CenterScreen; // 중앙에 위치
        this.MaximizeBox = false; // 최대화 버튼 비활성화
        this.FormBorderStyle = FormBorderStyle.FixedDialog; // 크기 조정 불가
        this.BackColor = System.Drawing.Color.White; // 기본 배경색

        // 그라데이션 배경
        this.Paint += (sender, e) =>
        {
            LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle,
                Color.FromArgb(240, 240, 240), Color.FromArgb(200, 200, 200), 90F);
            e.Graphics.FillRectangle(brush, this.ClientRectangle);
        };

        // 버튼 설정
        btnKillProcesses = new Button
        {
            Text = "Kill Processes",
            Location = new System.Drawing.Point(150, 70), // Point로 변경
            Size = new System.Drawing.Size(100, 40),
            BackColor = Color.FromArgb(255, 69, 58), // 버튼 색상
            ForeColor = Color.White, // 글자 색상
            Font = new System.Drawing.Font("Segoe UI", 12, FontStyle.Bold), // 폰트
            FlatStyle = FlatStyle.Flat // 평면 스타일
        };
        btnKillProcesses.FlatAppearance.BorderSize = 0; // 테두리 제거
        btnKillProcesses.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 85, 70); // 마우스 오버 색상
        btnKillProcesses.Click += BtnKillProcesses_Click;

        // 상태 레이블 설정
        lblStatus = new Label
        {
            Text = "Status: Ready",
            Location = new System.Drawing.Point(50, 120),
            Size = new System.Drawing.Size(300, 30),
            Font = new System.Drawing.Font("Segoe UI", 10), // 폰트 스타일
            ForeColor = Color.Black // 글자 색상
        };

        // 컨트롤 추가
        this.Controls.Add(btnKillProcesses);
        this.Controls.Add(lblStatus);
    }

    private void BtnKillProcesses_Click(object sender, EventArgs e)
    {
        lblStatus.Text = "Status: Killing processes...";
        KillProcesses();
        lblStatus.Text = "Status: Done";
    }

    private void KillProcesses()
    {
        // 제외 폴더 목록 설정
        var excludedFolders = new[] 
        {
            @"C:\Windows",
        };

        // 시스템 중요 프로세스 목록
        var importantProcesses = new[] 
        {
            "explorer",  // Windows 탐색기
            "System",    // 시스템 프로세스
            "svchost",   // 서비스 호스트 프로세스
            "csrss",     // 클라이언트/서버 런타임 프로세스
            "winlogon",  // Windows 로그인 프로세스
            "services",  // 서비스 제어 관리자
            "lsass",     // 로컬 보안 권한 하위 시스템 서비스
            "lmhosts",   // TCP/IP NetBIOS 헬퍼
            "smss",      // 세션 관리자 하위 시스템
            "wininit",   // Windows 초기화 프로세스
            "dwm",       // 데스크톱 윈도우 관리자
            "taskhostw", // 작업 호스트
            "rundll32",  // DLL을 앱으로 실행
            "taskeng"    // 작업 스케줄러 엔진
        };

        // 현재 실행 중인 모든 프로세스 가져오기
        var processes = Process.GetProcesses();

        foreach (var process in processes)
        {
            try
            {
                // 프로세스가 유효한지 확인
                if (process.HasExited)
                    continue;

                // 메인 윈도우가 없는 프로세스만 선택
                if (process.MainWindowHandle == IntPtr.Zero)
                {
                    string processPath = GetProcessPath(process);

                    // 프로세스 경로가 제외 폴더에 있는지 확인
                    if (!excludedFolders.Any(folder => IsInExcludedFolder(processPath, folder)) &&
                        !importantProcesses.Contains(process.ProcessName.ToLower())) // 중요 프로세스 체크
                    {
                        // 시스템 트레이와 관련된 프로세스 제외 (예: GUI 프로세스 제외)
                        if (!IsSystemTrayProcess(process))
                        {
                            // 프로세스와 연결된 서비스 중지
                            StopAssociatedServicesAndProcess(process);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // 예외 발생 시 처리
                Console.WriteLine($"Error handling process {process.Id}: {ex.Message}");
            }
        }
    }

    private string GetProcessPath(Process process)
    {
        try
        {
            return process.MainModule?.FileName ?? string.Empty;
        }
        catch
        {
            // 프로세스의 경로를 가져올 수 없는 경우
            return string.Empty;
        }
    }

    private bool IsInExcludedFolder(string path, string excludedFolder)
    {
        if (string.IsNullOrEmpty(path))
            return true; // 경로를 알 수 없는 경우 제외 폴더에 포함된 것으로 간주

        try
        {
            var processFolder = Path.GetDirectoryName(path);
            return processFolder != null && processFolder.StartsWith(excludedFolder, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            // 경로 검사 중 예외 발생 시 제외 폴더로 간주
            return true;
        }
    }

    private void StopAssociatedServicesAndProcess(Process process)
    {
        try
        {
            // 프로세스와 연결된 서비스 중지
            foreach (var service in ServiceController.GetServices())
            {
                try
                {
                    var serviceProcesses = Process.GetProcessesByName(service.ServiceName);
                    if (serviceProcesses.Any(p => p.Id == process.Id))
                    {
                        service.Stop();
                        service.WaitForStatus(ServiceControllerStatus.Stopped);
                    }
                }
                catch
                {
                    // 서비스 중지 중 예외 발생 시 무시
                }
            }

            // 프로세스 종료
            if (!process.HasExited)
            {
                process.Kill();
                process.WaitForExit();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error stopping process {process.Id}: {ex.Message}");
        }
        finally
        {
            // 프로세스 자원 해제
            process.Dispose();
        }
    }

    private bool IsSystemTrayProcess(Process process)
    {
        // 예시: 시스템 트레이와 관련된 GUI 프로세스 필터링 (일반적으로 GUI 프로세스는 MainWindowHandle이 null이 아니거나, 사용자 인터페이스를 표시)
        // 현재 간단한 예로서, `process.MainWindowHandle`이 null이 아닌 프로세스를 트레이 프로세스로 간주
        return process.MainWindowHandle != IntPtr.Zero;
    }

    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new MainForm());
    }
}
